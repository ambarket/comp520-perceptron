$Id: README.txt 35716 2004-12-29 03:56:57Z cxh $
See package.html
