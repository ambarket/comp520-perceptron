$Id: README.txt 61980 2011-09-13 23:38:25Z cxh $
See package.html
