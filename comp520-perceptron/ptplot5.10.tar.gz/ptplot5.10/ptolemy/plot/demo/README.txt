$Id: README.txt 62223 2011-10-09 05:28:51Z cxh $
See package.html
